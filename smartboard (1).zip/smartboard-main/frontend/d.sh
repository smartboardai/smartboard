#!/bin/bash
# pnpm run build
git add .
git commit -m "first commit"
git push -u origin main