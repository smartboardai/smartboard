#!/bin/bash
pnpm run dev