import { createPinia } from 'pinia'

export const store = createPinia()
