<script setup lang='ts'>
import SvgIcon from '../SvgIcon/index.vue'

</script>

<template>
    <div  class="flex  flex-col items-center justify-center h-full">
      <SvgIcon icon="eos-icons:loading" class="text-primary  text-3xl" />
   </div>
</template>
