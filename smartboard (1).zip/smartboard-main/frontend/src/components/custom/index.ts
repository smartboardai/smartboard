import GithubSite from './GithubSite.vue'

export { GithubSite }
