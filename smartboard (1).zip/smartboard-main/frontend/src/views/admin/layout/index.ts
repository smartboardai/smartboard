import AdminLayout from './Layout.vue'

export { AdminLayout }
