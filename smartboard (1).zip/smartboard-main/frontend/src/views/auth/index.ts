import AuthLayout from './index.vue'

export { AuthLayout }
